package controller;

import java.util.ArrayList;

import model.*;
import view.Vista;

public class Controlador {
	private static ArrayList<Cliente> clientes = new ArrayList<>();
	private static ArrayList<Articulo> articulos = new ArrayList<>();
	private static ArrayList<Pedido> pedidos = new ArrayList<>();

	public void arrancar() {
		agregarCliente();
		Vista.imprimirTitulos();
		String f = "%8s %20s %58s %20s %15s %15s %n";
		for (Cliente e : clientes) {
			String s = hallarStatus(e);
			if (s.equalsIgnoreCase("cliente")) {
				Vista.imprimirClientes(f, e.getNumCliente(), s, e.getDirecciones(), e.getSaldo(), 0, 0);
			} else if (s.equalsIgnoreCase("VIP") && e instanceof ClienteVIP) {
				ClienteVIP clienteVIP = (ClienteVIP) e;
				Vista.imprimirClientes(f, e.getNumCliente(), s, e.getDirecciones(), e.getSaldo(),
						clienteVIP.getLimiteCred(), clienteVIP.getDescuento());
			}
		}
	}

	public static void agregarCliente() {
		ArrayList<String> direccionesCliente1 = new ArrayList<>();
		direccionesCliente1.add("A: Calle 29, Cali");
		direccionesCliente1.add("B: Avenida 12, Barranquilla");
		clientes.add(new Cliente(1, "cliente", direccionesCliente1, 850000));
		ArrayList<String> direccionesCliente2 = new ArrayList<>();
		direccionesCliente2.add("A: Carrera 54, Bogotá");
		direccionesCliente2.add("B: Avenida 7, Pasto");
		clientes.add(new ClienteVIP(2, "VIP", direccionesCliente2, 1200000, 300000, 0.15));
		ArrayList<String> direccionesCliente3 = new ArrayList<>();
		direccionesCliente3.add("A: Calle 32, Cota");
		direccionesCliente3.add("B: Carrera 2, Tunja");
		clientes.add(new Cliente(4, "cliente", direccionesCliente3, 585000));
		ArrayList<String> direccionesCliente4 = new ArrayList<>();
		direccionesCliente4.add("A: Calle 69, Medellin");
		clientes.add(new ClienteVIP(3, "VIP", direccionesCliente4, 5000000, 450000, 0.35));
		ArrayList<String> direccionesCliente5 = new ArrayList<>();
		direccionesCliente5.add("A: Local 23 CC Aquarium, Bogotá");
		clientes.add(new Cliente(5, "cliente", direccionesCliente5, 720000));
		ArrayList<String> direccionesCliente6 = new ArrayList<>();
		direccionesCliente6.add("A: Carrera 123, Bogotá");
		direccionesCliente6.add("B: Diagonal 38, Cali");
		clientes.add(new ClienteVIP(6, "VIP", direccionesCliente6, 385000, 3600000, 0.25));
	}

	public static void agregarArticulo(Articulo articulo) {
		articulos.add(articulo);
	}

	public static void realizarPedido(Cliente cliente, Articulo articulo, int cantidad) {
		pedidos.add(new Pedido(cliente, articulo, cantidad));
	}

	public String hallarStatus(Cliente o) {
		String status = "";
		if (o instanceof ClienteVIP) {
			status = "VIP";
		} else {
			status = "Cliente";
		}
		return status;
	}

}
