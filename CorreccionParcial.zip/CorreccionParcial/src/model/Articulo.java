package model;

import java.util.List;
import java.util.Map;

public class Articulo {
	private int numeroArticulo;
	private List<String> fabricasDistribuidoras;
	private Map<String, Integer> existencias;
	private String descripcion;

	public Articulo(int numeroArticulo, List<String> fabricasDistribuidoras, Map<String, Integer> existencias,
			String descripcion) {
		super();
		this.numeroArticulo = numeroArticulo;
		this.fabricasDistribuidoras = fabricasDistribuidoras;
		this.existencias = existencias;
		this.descripcion = descripcion;
	}

	public int getNumeroArticulo() {
		return numeroArticulo;
	}

	public void setNumeroArticulo(int numeroArticulo) {
		this.numeroArticulo = numeroArticulo;
	}

	public List<String> getFabricasDistribuidoras() {
		return fabricasDistribuidoras;
	}

	public void setFabricasDistribuidoras(List<String> fabricasDistribuidoras) {
		this.fabricasDistribuidoras = fabricasDistribuidoras;
	}

	public Map<String, Integer> getExistencias() {
		return existencias;
	}

	public void setExistencias(Map<String, Integer> existencias) {
		this.existencias = existencias;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Articulo [numeroArticulo=" + numeroArticulo + ", fabricasDistribuidoras=" + fabricasDistribuidoras
				+ ", existencias=" + existencias + ", descripcion=" + descripcion + "]";
	}

}
