package model;

import java.util.ArrayList;

public class Cliente {
	private int numCliente;
	private String status;
	private ArrayList<String> direcciones;
	private double Saldo;

	public Cliente(int numCliente, String status, ArrayList<String> direcciones, double saldo) {
		super();
		this.numCliente = numCliente;
		this.direcciones = direcciones;
		Saldo = saldo;
	}

	public Cliente() {

	}

	public int getNumCliente() {
		return numCliente;
	}

	public void setNumCliente(int numCliente) {
		this.numCliente = numCliente;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ArrayList<String> getDirecciones() {
		return direcciones;
	}

	public void setDirecciones(ArrayList<String> direcciones) {
		this.direcciones = direcciones;
	}

	public double getSaldo() {
		return Saldo;
	}

	public void setSaldo(double saldo) {
		Saldo = saldo;
	}

	@Override
	public String toString() {
		return "Cliente [numCliente=" + numCliente + ", status=" + status + ", direcciones=" + direcciones + ", Saldo="
				+ Saldo + "]";
	}
	
}
