package model;

import java.util.ArrayList;

public class ClienteVIP extends Cliente {
	private double limiteCred;
	private double descuento;

	public ClienteVIP() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClienteVIP(int numCliente, String status, ArrayList<String> direcciones, double saldo) {
		super(numCliente, status, direcciones, saldo);
		// TODO Auto-generated constructor stub
	}

	public ClienteVIP(int numCliente, String status, ArrayList<String> direcciones, double saldo, double limiteCred,
			double descuento) {
		super(numCliente, status, direcciones, saldo);
		this.limiteCred = limiteCred;
		this.descuento = descuento;
	}

	public double getLimiteCred() {
		return limiteCred;
	}

	public void setLimiteCred(double limiteCred) {
		this.limiteCred = limiteCred;
	}

	public double getDescuento() {
		return descuento;
	}

	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}

	@Override
	public String toString() {
		return "ClienteVIP [limiteCred=" + limiteCred + ", descuento=" + descuento + "]";
	}

}
