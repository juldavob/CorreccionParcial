package model;

public class Pedido {
	private Cliente cliente;
	private Articulo articulo;
	private int cantidad;

	public Pedido(Cliente cliente, Articulo articulo, int cantidad) {
		super();
		this.cliente = cliente;
		this.articulo = articulo;
		this.cantidad = cantidad;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "Pedido [cliente=" + cliente + ", articulo=" + articulo + ", cantidad=" + cantidad + "]";
	}
}
