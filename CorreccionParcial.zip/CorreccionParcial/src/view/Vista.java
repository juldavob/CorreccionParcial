package view;

import java.util.ArrayList;

public class Vista {
	public static void imprimirTitulos() {
		System.out.println();

		System.out.format("%8s %20s %50s %20s %20s %20s %20s %n", "| Numero Cliente |", "Status |", "Direcciones |", "Saldo |", "Limite Credito |", "Descuento |", "\n");

		System.out.println("|________________|____________________|__________________________________________________|____________________|____________________|____________________|");
	}

	public static void imprimirClientes(String formato, int numCliente, String status, ArrayList<String> direcciones,
			double saldo, double limiteCred, double descuento) {

		System.out.format(formato, numCliente, status, direcciones, saldo, limiteCred, descuento);

	}
}
