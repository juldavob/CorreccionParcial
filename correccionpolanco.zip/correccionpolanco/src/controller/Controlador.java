package controller;

import java.util.ArrayList;
import model.*;
import view.Ventana;

public class Controlador {

    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Articulo> articulos = new ArrayList<>();

    public void arrancar() {
        registrarClientes();
        registrarArticulos();
        realizarPedidos();
        actualizarExistencias();
        calcularValorPagar();
        Ventana.mostrarClientes(clientes);
    }

    public void registrarClientes() {
      
        clientes.add(new Cliente(1, new String[]{"Calle 152, Ciudad Bogota", "Calle 85b, Ciudad Cali"}, 100000, 2000000, 0.1));
        clientes.add(new Cliente(2, new String[]{"Calle 39, Ciudad Medellin", "Calle 96c, Ciudad Cartagena"}, 200000, 1500000, 0.05));
    }

    public void registrarArticulos() {
        
        articulos.add(new Articulo(1, new String[]{"Fabrica 1", "Fabrica 2"}, new int[]{70, 100}, "Descripción del artículo 1", 5000));
        articulos.add(new Articulo(2, new String[]{"Fabrica 3", "Fabrica 4"}, new int[]{10, 70}, "Descripción del artículo 2", 7000));
    }

    public void realizarPedidos() {
       
        clientes.get(0).realizarPedido(new Pedido(1, 10));
        clientes.get(1).realizarPedido(new Pedido(3, 40));
    }

    public void actualizarExistencias() {
      
        for (Cliente cliente : clientes) {
            for (Pedido pedido : cliente.getPedidos()) {
                int idArticulo = pedido.getIdArticulo();
                int cantidad = pedido.getCantidad();
                Articulo articulo = buscarArticuloPorId(idArticulo);
                if (articulo != null) {
                    int index = articulos.indexOf(articulo);
                    int[] existencias = articulo.getExistencias();
                    existencias[index] -= cantidad;
                    articulo.setExistencias(existencias);
                }
            }
        }
    }

    public void calcularValorPagar() {
       
        for (Cliente cliente : clientes) {
            double valorPagar = 0;
            for (Pedido pedido : cliente.getPedidos()) {
                int idArticulo = pedido.getIdArticulo();
                int cantidad = pedido.getCantidad();
                Articulo articulo = buscarArticuloPorId(idArticulo);
                if (articulo != null) {
                    double precioUnitario = articulo.getPrecio();
                    valorPagar += precioUnitario * cantidad;
                }
            }
            cliente.setValorPagar(valorPagar);
        }
    }

    private Articulo buscarArticuloPorId(int idArticulo) {
        for (Articulo articulo : articulos) {
            if (articulo.getId() == idArticulo) {
                return articulo;
            }
        }
        return null;
    }
}