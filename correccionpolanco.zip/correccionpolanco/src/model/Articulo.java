package model;

import java.util.Arrays;

public class Articulo {
    private int id;
    private String[] fabricasDistribuidoras;
    private int[] existencias;
    private String descripcion;
    private double precio;

    public Articulo(int id, String[] fabricasDistribuidoras, int[] existencias, String descripcion, double precio) {
        this.id = id;
        this.fabricasDistribuidoras = fabricasDistribuidoras;
        this.existencias = existencias;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String[] getFabricasDistribuidoras() {
        return fabricasDistribuidoras;
    }

    public void setFabricasDistribuidoras(String[] fabricasDistribuidoras) {
        this.fabricasDistribuidoras = fabricasDistribuidoras;
    }

    public int[] getExistencias() {
        return existencias;
    }

    public void setExistencias(int[] existencias) {
        this.existencias = existencias;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }


	public Articulo() {
		super();
		// TODO Auto-generated constructor stub
	}




	@Override
	public String toString() {
		return "Articulo [id=" + id + ", fabricasDistribuidoras=" + Arrays.toString(fabricasDistribuidoras)
				+ ", existencias=" + Arrays.toString(existencias) + ", descripcion=" + descripcion + ", precio="
				+ precio + "]";
	}
    
}