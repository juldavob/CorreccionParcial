package model;

import java.util.ArrayList;
import java.util.Arrays;

public class Cliente {
    private int numeroCliente;
    private String[] direccionesEnvio;
    private double saldo;
    private double limiteCredito;
    private double descuento;
    private ArrayList<Pedido> pedidos;
    private double valorPagar;

    public Cliente(int numeroCliente, String[] direccionesEnvio, double saldo, double limiteCredito, double descuento) {
        this.numeroCliente = numeroCliente;
        this.direccionesEnvio = direccionesEnvio;
        this.saldo = saldo;
        this.limiteCredito = limiteCredito;
        this.descuento = descuento;
        this.pedidos = new ArrayList<>();
        this.valorPagar = 0;
        
    }

    public void realizarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

  
    public int getNumeroCliente() {
        return numeroCliente;
    }

    public void setNumeroCliente(int numeroCliente) {
        this.numeroCliente = numeroCliente;
    }

    public String[] getDireccionesEnvio() {
        return direccionesEnvio;
    }

    public void setDireccionesEnvio(String[] direccionesEnvio) {
        this.direccionesEnvio = direccionesEnvio;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(double limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(ArrayList<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public double getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(double valorPagar) {
        this.valorPagar = valorPagar;
    }

	public Cliente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cliente(int numeroCliente, String[] direccionesEnvio, double saldo, double limiteCredito, double descuento,
			ArrayList<Pedido> pedidos, double valorPagar) {
		super();
		this.numeroCliente = numeroCliente;
		this.direccionesEnvio = direccionesEnvio;
		this.saldo = saldo;
		this.limiteCredito = limiteCredito;
		this.descuento = descuento;
		this.pedidos = pedidos;
		this.valorPagar = valorPagar;
	}

	@Override
	public String toString() {
		return "Cliente [numeroCliente=" + numeroCliente + ", direccionesEnvio=" + Arrays.toString(direccionesEnvio)
				+ ", saldo=" + saldo + ", limiteCredito=" + limiteCredito + ", descuento=" + descuento + ", pedidos="
				+ pedidos + ", valorPagar=" + valorPagar + "]";
	}
    
}