package model;

public class Pedido {
    private int idArticulo;
    private int cantidad;

    public Pedido(int idArticulo, int cantidad) {
        this.idArticulo = idArticulo;
        this.cantidad = cantidad;
    }

    
    public int getIdArticulo() {
        return idArticulo;
    }

    public void setIdArticulo(int idArticulo) {
        this.idArticulo = idArticulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }


	public Pedido() {
		super();
		// TODO Auto-generated constructor stub
	}



	@Override
	public String toString() {
		return "Pedido [idArticulo=" + idArticulo + ", cantidad=" + cantidad + "]";
	}
    
}