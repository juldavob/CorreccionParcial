package view;

import java.util.ArrayList;
import java.util.Scanner;
import model.Cliente;

public class Ventana {
    private static Scanner sc = new Scanner(System.in);

    public static void mostrarTituloClientes() {
        System.out.format("%14s %20s %40s %30s %14s %n", "Número Cliente", "Direcciones Envío", "Saldo", "Límite Crédito", "Descuento");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
    }

    public static void mostrarClientes(ArrayList<Cliente> clientes) {
        mostrarTituloClientes();
        for (Cliente cliente : clientes) {
        	 String direcciones = String.join(", ", cliente.getDireccionesEnvio());
            System.out.format("%5s %65s %25s %20s %14s %n", cliente.getNumeroCliente(), direcciones, cliente.getSaldo(), cliente.getLimiteCredito(), cliente.getDescuento());
        }
    }

    public static double pedirPrecioArticulo() {
        System.out.println("Ingrese el precio del artículo:");
        return sc.nextDouble();
    }
}
